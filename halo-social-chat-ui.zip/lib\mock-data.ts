import { Community, Message, User } from "@/lib/types";

export const users: User[] = [
  {
    id: "mira",
    name: "Mira Chen",
    handle: "@mira",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=240&q=80",
    banner: "https://images.unsplash.com/photo-1519608487953-e999c86e7455?auto=format&fit=crop&w=1200&q=80",
    note: "Shipping tiny delights ✨",
    noteExpiresIn: "18h",
    status: "online",
    customStatus: "Design review at 4",
    bio: "Product designer, community host, and midnight playlist curator. Building calmer social spaces.",
    links: ["mira.design", "instagram.com/mira", "dribbble.com/mira"]
  },
  {
    id: "kai",
    name: "Kai Morgan",
    handle: "@kai",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=240&q=80",
    banner: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&w=1200&q=80",
    note: "Voice room later?",
    noteExpiresIn: "9h",
    status: "away",
    customStatus: "Deep work",
    bio: "Frontend engineer, synthwave fan, and weekend climber.",
    links: ["kai.dev", "github.com/kai"]
  },
  {
    id: "noor",
    name: "Noor Silva",
    handle: "@noor",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=240&q=80",
    banner: "https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1200&q=80",
    note: "New city, same coffee ☕",
    noteExpiresIn: "23h",
    status: "busy",
    customStatus: "Recording",
    bio: "Community strategist helping creators build thoughtful member spaces.",
    links: ["noorsilva.co", "threads.net/@noor"]
  },
  {
    id: "ezra",
    name: "Ezra Park",
    handle: "@ezra",
    avatar: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=240&q=80",
    banner: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80",
    note: "Ask me about bots",
    noteExpiresIn: "12h",
    status: "invisible",
    customStatus: "Offline-ish",
    bio: "Automation tinkerer and community moderator.",
    links: ["ezrapark.dev"]
  }
];

export const communities: Community[] = [
  {
    id: "design-lab",
    name: "Design Lab",
    icon: "DL",
    accent: "from-cyan-400 to-fuchsia-400",
    banner: "https://images.unsplash.com/photo-1558655146-9f40138edfeb?auto=format&fit=crop&w=1200&q=80",
    members: 12840,
    online: 1462,
    description: "A premium studio lounge for product designers, visual thinkers, and design engineers.",
    textChannels: ["announcements", "daily-notes", "feedback", "figma-lounge", "jobs"],
    voiceChannels: ["Studio One", "Crit Room", "Quiet Co-working"]
  },
  {
    id: "night-owls",
    name: "Night Owls",
    icon: "NO",
    accent: "from-violet-400 to-blue-400",
    banner: "https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80",
    members: 8421,
    online: 932,
    description: "Late-night builders, writers, and curious people keeping each other company.",
    textChannels: ["midnight-chat", "music", "small-wins", "snacks"],
    voiceChannels: ["Lo-fi Room", "Open Mic"]
  },
  {
    id: "creator-house",
    name: "Creator House",
    icon: "CH",
    accent: "from-emerald-300 to-sky-400",
    banner: "https://images.unsplash.com/photo-1497366754035-f200968a6e72?auto=format&fit=crop&w=1200&q=80",
    members: 19052,
    online: 2188,
    description: "A network for creators sharing drafts, launch notes, analytics, and collaborations.",
    textChannels: ["launches", "scripts", "analytics", "collabs"],
    voiceChannels: ["Pitch Practice", "Editing Sprint", "Creator Cafe"]
  }
];

export const messages: Message[] = [
  {
    id: "1",
    author: users[0],
    text: "The new notes tray feels lovely on mobile. I added emoji reactions to the prototype too.",
    time: "10:42",
    reactions: [
      { emoji: "✨", count: 7 },
      { emoji: "🔥", count: 3 }
    ]
  },
  {
    id: "2",
    author: users[1],
    text: "Can we make voice messages feel more tactile? Maybe a waveform pill next to the send controls.",
    time: "10:45",
    reactions: [{ emoji: "🎙️", count: 5 }],
    attachment: "voice-concept.fig"
  },
  {
    id: "3",
    author: users[2],
    text: "Friend requests and community mentions are both in the notifications pass now.",
    time: "10:48",
    reactions: [{ emoji: "✅", count: 4 }]
  }
];

export const notifications = [
  { title: "Mira mentioned you", detail: "#feedback in Design Lab", type: "Mention", time: "2m" },
  { title: "Jules sent a friend request", detail: "Suggested by Noor", type: "Friend", time: "12m" },
  { title: "Night Owls is live", detail: "Lo-fi Room has 8 speakers", type: "Voice", time: "23m" },
  { title: "Creator House weekly digest", detail: "14 launches and 32 new notes", type: "Community", time: "1h" }
];
