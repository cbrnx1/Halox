import { MessageCircle, UserPlus } from "lucide-react";
import { notFound } from "next/navigation";
import { AppShell } from "@/components/app/app-shell";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { users } from "@/lib/mock-data";

export default async function ProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const user = users.find((item) => item.id === id);

  if (!user) {
    notFound();
  }

  return (
    <AppShell>
      <Card className="mx-auto max-w-5xl overflow-hidden">
        <div className="h-48 bg-cover bg-center sm:h-64" style={{ backgroundImage: `url(${user.banner})` }} />
        <div className="p-5 sm:p-7">
          <div className="-mt-20 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="flex items-end gap-4">
              <Avatar src={user.avatar} alt={user.name} status={user.status} size="xl" />
              <div className="pb-2">
                <div className="text-2xl font-semibold">{user.name}</div>
                <div className="text-sm text-zinc-400">{user.handle}</div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button><UserPlus className="h-4 w-4" /> Friend</Button>
              <Button variant="secondary"><MessageCircle className="h-4 w-4" /> Message</Button>
            </div>
          </div>
          <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_320px]">
            <div>
              <div className="mb-2 text-sm font-semibold">Bio</div>
              <p className="text-sm leading-6 text-zinc-300">{user.bio}</p>
              <div className="mt-5">
                <div className="mb-2 text-sm font-semibold">Social links</div>
                <div className="flex flex-wrap gap-2">
                  {user.links.map((link) => (
                    <Badge key={link} className="text-cyan-100">{link}</Badge>
                  ))}
                </div>
              </div>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/[0.06] p-4">
              <div className="text-sm font-semibold">Current note</div>
              <div className="mt-3 rounded-xl bg-black/25 p-4 text-sm text-zinc-200">{user.note}</div>
              <div className="mt-2 text-xs text-zinc-500">Expires in {user.noteExpiresIn}</div>
              <div className="mt-5 text-sm font-semibold">Status</div>
              <Badge className="mt-3 capitalize">{user.status}</Badge>
              <div className="mt-2 text-sm text-zinc-400">{user.customStatus}</div>
            </div>
          </div>
        </div>
      </Card>
    </AppShell>
  );
}
