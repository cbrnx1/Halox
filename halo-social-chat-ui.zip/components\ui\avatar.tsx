import { cn } from "@/lib/utils";
import { Status } from "@/lib/types";

const statusColor: Record<Status, string> = {
  online: "bg-emerald-400",
  away: "bg-amber-400",
  busy: "bg-rose-500",
  invisible: "bg-zinc-500"
};

type AvatarProps = {
  src: string;
  alt: string;
  status?: Status;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
};

export function Avatar({ src, alt, status, size = "md", className }: AvatarProps) {
  return (
    <div
      className={cn(
        "relative shrink-0 overflow-visible rounded-full",
        size === "sm" && "h-9 w-9",
        size === "md" && "h-11 w-11",
        size === "lg" && "h-14 w-14",
        size === "xl" && "h-24 w-24",
        className
      )}
    >
      <img src={src} alt={alt} className="h-full w-full rounded-full object-cover ring-2 ring-white/10" />
      {status ? (
        <span
          className={cn(
            "absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full ring-2 ring-[#11131b]",
            statusColor[status]
          )}
        />
      ) : null}
    </div>
  );
}
