"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

type ButtonProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "icon";
};

export function Button({
  className,
  variant = "primary",
  size = "md",
  ...props
}: ButtonProps) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300 disabled:pointer-events-none disabled:opacity-50",
        variant === "primary" &&
          "bg-white text-zinc-950 shadow-glow hover:-translate-y-0.5 hover:bg-cyan-100",
        variant === "secondary" &&
          "border border-white/10 bg-white/[0.08] text-white hover:bg-white/[0.14]",
        variant === "ghost" && "text-zinc-300 hover:bg-white/10 hover:text-white",
        variant === "danger" && "bg-rose-500 text-white hover:bg-rose-400",
        size === "sm" && "h-9 px-3 text-sm",
        size === "md" && "h-11 px-4 text-sm",
        size === "icon" && "h-10 w-10 p-0",
        className
      )}
      {...props}
    />
  );
}
