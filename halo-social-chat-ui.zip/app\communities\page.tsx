import { AppShell } from "@/components/app/app-shell";
import { CommunityGrid } from "@/components/app/community-view";

export default function CommunitiesPage() {
  return (
    <AppShell>
      <div className="mb-5">
        <h1 className="text-2xl font-semibold">Communities</h1>
        <p className="mt-2 text-sm text-zinc-500">Discover Discord-style spaces with channels, voice rooms, members, and live notes.</p>
      </div>
      <CommunityGrid />
    </AppShell>
  );
}
