export type Status = "online" | "away" | "busy" | "invisible";

export type User = {
  id: string;
  name: string;
  handle: string;
  avatar: string;
  banner: string;
  note?: string;
  noteExpiresIn?: string;
  status: Status;
  customStatus?: string;
  bio: string;
  links: string[];
};

export type Community = {
  id: string;
  name: string;
  icon: string;
  accent: string;
  banner: string;
  members: number;
  online: number;
  description: string;
  textChannels: string[];
  voiceChannels: string[];
};

export type Message = {
  id: string;
  author: User;
  text: string;
  time: string;
  reactions: Array<{ emoji: string; count: number }>;
  attachment?: string;
};
