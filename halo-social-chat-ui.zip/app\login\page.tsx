import { AuthPanel } from "@/components/app/auth-panel";

export default function LoginPage() {
  return <AuthPanel mode="login" />;
}
