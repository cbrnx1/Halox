import { Bell, MessageCircle, Radio, UserPlus } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { notifications } from "@/lib/mock-data";

export default function NotificationsPage() {
  return (
    <AppShell>
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Notifications</h1>
          <p className="mt-2 text-sm text-zinc-500">Friend requests, mentions, messages, and community updates.</p>
        </div>
        <Button variant="secondary">Mark all read</Button>
      </div>
      <Card className="divide-y divide-white/[0.08] overflow-hidden">
        {notifications.concat(notifications).map((item, index) => {
          const Icon = item.type === "Friend" ? UserPlus : item.type === "Voice" ? Radio : item.type === "Mention" ? MessageCircle : Bell;
          return (
            <div key={`${item.title}-${index}`} className="flex gap-3 p-4 transition hover:bg-white/[0.06]">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-white/[0.08]">
                <Icon className="h-5 w-5 text-cyan-200" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-medium">{item.title}</span>
                  <Badge>{item.type}</Badge>
                </div>
                <div className="mt-1 text-sm text-zinc-500">{item.detail}</div>
              </div>
              <span className="text-xs text-zinc-500">{item.time}</span>
            </div>
          );
        })}
      </Card>
    </AppShell>
  );
}
