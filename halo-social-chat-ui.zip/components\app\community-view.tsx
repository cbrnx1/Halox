"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { Hash, Mic2, ShieldCheck, Volume2 } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { communities, users } from "@/lib/mock-data";
import { Community } from "@/lib/types";
import { cn } from "@/lib/utils";

export function CommunityGrid() {
  return (
    <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
      {communities.map((community, index) => (
        <motion.div
          key={community.id}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.06 }}
        >
          <Link href={`/communities/${community.id}`}>
            <Card className="group overflow-hidden">
              <div className="h-36 bg-cover bg-center transition duration-500 group-hover:scale-[1.03]" style={{ backgroundImage: `url(${community.banner})` }} />
              <div className="p-4">
                <div className="-mt-10 mb-3 flex h-16 w-16 items-center justify-center rounded-xl border border-white/20 bg-zinc-950 text-lg font-black shadow-panel">
                  <span className={cn("bg-gradient-to-br bg-clip-text text-transparent", community.accent)}>{community.icon}</span>
                </div>
                <div className="text-lg font-semibold">{community.name}</div>
                <p className="mt-2 line-clamp-2 text-sm leading-6 text-zinc-400">{community.description}</p>
                <div className="mt-4 flex gap-2">
                  <Badge>{community.members.toLocaleString()} members</Badge>
                  <Badge className="text-emerald-300">{community.online.toLocaleString()} online</Badge>
                </div>
              </div>
            </Card>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}

export function CommunityProfile({ community }: { community: Community }) {
  return (
    <div className="grid gap-4 xl:grid-cols-[280px_1fr_260px]">
      <section className="glass overflow-hidden rounded-xl xl:sticky xl:top-24 xl:h-[calc(100vh-120px)]">
        <div className="h-28 bg-cover bg-center" style={{ backgroundImage: `url(${community.banner})` }} />
        <div className="p-4">
          <div className="-mt-10 mb-3 flex h-16 w-16 items-center justify-center rounded-xl border border-white/20 bg-zinc-950 text-lg font-black">
            <span className={cn("bg-gradient-to-br bg-clip-text text-transparent", community.accent)}>{community.icon}</span>
          </div>
          <div className="font-semibold">{community.name}</div>
          <p className="mt-2 text-sm leading-6 text-zinc-400">{community.description}</p>
          <Button className="mt-4 w-full">Join community</Button>
        </div>
        <div className="border-t border-white/[0.08] p-3">
          <div className="mb-2 px-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">Text channels</div>
          {community.textChannels.map((channel) => (
            <button key={channel} className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm text-zinc-400 hover:bg-white/[0.08] hover:text-white">
              <Hash className="h-4 w-4" /> {channel}
            </button>
          ))}
          <div className="mb-2 mt-4 px-2 text-xs font-semibold uppercase tracking-wider text-zinc-500">Voice channels</div>
          {community.voiceChannels.map((channel) => (
            <button key={channel} className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-sm text-zinc-400 hover:bg-white/[0.08] hover:text-white">
              <Volume2 className="h-4 w-4" /> {channel}
            </button>
          ))}
        </div>
      </section>

      <section className="glass rounded-xl p-4">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xl font-semibold">
              <Hash className="h-5 w-5 text-cyan-200" /> daily-notes
            </div>
            <div className="mt-1 text-sm text-zinc-500">Community updates, notes, and live chat</div>
          </div>
          <Badge className="text-emerald-300"><Mic2 className="mr-1 h-3.5 w-3.5" /> 3 voice rooms active</Badge>
        </div>
        <div className="space-y-3">
          {users.map((user, index) => (
            <motion.article
              key={user.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="rounded-xl border border-white/[0.08] bg-white/[0.06] p-3"
            >
              <div className="flex items-start gap-3">
                <Avatar src={user.avatar} alt={user.name} status={user.status} />
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-medium">{user.name}</span>
                    {index === 0 ? <Badge className="text-cyan-200"><ShieldCheck className="mr-1 h-3 w-3" /> Mod</Badge> : null}
                    <span className="text-xs text-zinc-500">{index + 4}m ago</span>
                  </div>
                  <p className="mt-1 text-sm leading-6 text-zinc-300">
                    {index === 0
                      ? "Drop your rough notes from today's builds. Tiny updates count."
                      : user.note ?? user.customStatus}
                  </p>
                </div>
              </div>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="glass rounded-xl p-4">
        <div className="mb-4 text-sm font-semibold">Members</div>
        <div className="space-y-3">
          {users.map((user) => (
            <Link href={`/profile/${user.id}`} key={user.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-white/[0.08]">
              <Avatar src={user.avatar} alt={user.name} status={user.status} size="sm" />
              <div className="min-w-0">
                <div className="truncate text-sm">{user.name}</div>
                <div className="truncate text-xs text-zinc-500">{user.handle}</div>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
