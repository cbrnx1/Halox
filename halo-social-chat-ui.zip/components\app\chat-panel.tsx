"use client";

import { motion } from "framer-motion";
import { File, Mic, Paperclip, Plus, Send, Smile } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { messages, users } from "@/lib/mock-data";

export function ChatPanel() {
  return (
    <div className="grid min-h-[calc(100vh-124px)] gap-4 xl:grid-cols-[320px_1fr]">
      <section className="glass overflow-hidden rounded-xl">
        <div className="border-b border-white/[0.08] p-4">
          <div className="text-sm font-semibold">Direct messages</div>
          <div className="mt-3">
            <Input placeholder="Find a conversation" />
          </div>
        </div>
        <div className="space-y-1 p-2">
          {users.map((user, index) => (
            <button
              key={user.id}
              className="flex w-full items-center gap-3 rounded-lg p-3 text-left transition hover:bg-white/[0.08]"
            >
              <Avatar src={user.avatar} alt={user.name} status={user.status} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-3">
                  <span className="truncate text-sm font-medium">{user.name}</span>
                  <span className="text-xs text-zinc-500">{index === 0 ? "now" : `${index + 2}m`}</span>
                </div>
                <div className="truncate text-xs text-zinc-500">{user.note ?? user.customStatus}</div>
              </div>
            </button>
          ))}
        </div>
      </section>

      <section className="glass flex min-h-[640px] flex-col overflow-hidden rounded-xl">
        <header className="flex items-center justify-between border-b border-white/[0.08] p-4">
          <div className="flex items-center gap-3">
            <Avatar src={users[0].avatar} alt={users[0].name} status={users[0].status} />
            <div>
              <div className="font-semibold">{users[0].name}</div>
              <div className="text-xs text-emerald-300">Online • {users[0].customStatus}</div>
            </div>
          </div>
          <Button variant="secondary" size="sm">View profile</Button>
        </header>

        <div className="flex-1 space-y-4 overflow-y-auto p-4">
          {messages.map((message, index) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.06 }}
              className="group flex gap-3"
            >
              <Avatar src={message.author.avatar} alt={message.author.name} status={message.author.status} />
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex items-center gap-2">
                  <span className="text-sm font-semibold">{message.author.name}</span>
                  <span className="text-xs text-zinc-500">{message.time}</span>
                </div>
                <div className="rounded-xl rounded-tl-sm border border-white/[0.08] bg-white/[0.08] p-3 text-sm leading-6 text-zinc-200">
                  {message.text}
                  {message.attachment ? (
                    <div className="mt-3 inline-flex items-center gap-2 rounded-lg border border-white/10 bg-black/25 px-3 py-2 text-xs text-cyan-100">
                      <File className="h-4 w-4" />
                      {message.attachment}
                    </div>
                  ) : null}
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {message.reactions.map((reaction) => (
                    <button key={reaction.emoji} className="rounded-full border border-white/10 bg-white/[0.08] px-2 py-1 text-xs text-zinc-300 transition hover:bg-white/[0.14]">
                      {reaction.emoji} {reaction.count}
                    </button>
                  ))}
                  <button className="rounded-full border border-white/10 bg-white/5 px-2 py-1 text-xs text-zinc-500 transition hover:text-white">
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
          <div className="flex items-center gap-2 pl-14 text-xs text-zinc-500">
            <span className="flex gap-1">
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-300" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-300 [animation-delay:120ms]" />
              <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-cyan-300 [animation-delay:240ms]" />
            </span>
            Kai is typing
          </div>
        </div>

        <footer className="border-t border-white/[0.08] p-3">
          <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/[0.24] p-2">
            <Button variant="ghost" size="icon" aria-label="Attach file">
              <Paperclip className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" aria-label="Voice message">
              <Mic className="h-4 w-4" />
            </Button>
            <input className="min-w-0 flex-1 bg-transparent px-2 text-sm outline-none placeholder:text-zinc-500" placeholder="Message Mira" />
            <Button variant="ghost" size="icon" aria-label="Emoji">
              <Smile className="h-4 w-4" />
            </Button>
            <Button size="icon" aria-label="Send message">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </footer>
      </section>
    </div>
  );
}
