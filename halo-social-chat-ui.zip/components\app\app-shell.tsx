"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  Bell,
  Compass,
  Home,
  MessageCircle,
  Search,
  Settings,
  Sparkles,
  UserRound,
  UsersRound
} from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { communities, users } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

const nav = [
  { href: "/", label: "Home", icon: Home },
  { href: "/messages", label: "DMs", icon: MessageCircle },
  { href: "/communities", label: "Communities", icon: Compass },
  { href: "/friends", label: "Friends", icon: UsersRound },
  { href: "/notifications", label: "Alerts", icon: Bell },
  { href: "/settings", label: "Settings", icon: Settings }
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="min-h-screen overflow-hidden bg-mesh-dark text-white">
      <div className="mx-auto flex min-h-screen max-w-[1600px]">
        <aside className="hidden w-[92px] shrink-0 border-r border-white/[0.08] bg-black/25 px-4 py-5 backdrop-blur-xl lg:block">
          <Link href="/" className="mb-6 flex h-12 w-12 items-center justify-center rounded-xl bg-white text-zinc-950 shadow-glow">
            <Sparkles className="h-5 w-5" />
          </Link>
          <div className="space-y-3">
            {communities.map((community) => (
              <Link
                href={`/communities/${community.id}`}
                key={community.id}
                className={cn(
                  "group relative flex h-12 w-12 items-center justify-center rounded-xl bg-white/[0.08] text-sm font-bold text-white transition hover:rounded-lg hover:bg-white/[0.14]"
                )}
              >
                <span className={cn("absolute inset-0 rounded-xl bg-gradient-to-br opacity-[0.45] blur-md", community.accent)} />
                <span className="relative">{community.icon}</span>
              </Link>
            ))}
          </div>
        </aside>

        <aside className="hidden w-[248px] shrink-0 border-r border-white/[0.08] bg-black/[0.18] px-4 py-5 backdrop-blur-xl xl:block">
          <div className="mb-5 flex items-center gap-3">
            <Avatar src={users[0].avatar} alt={users[0].name} status="online" />
            <div className="min-w-0">
              <div className="truncate text-sm font-semibold">{users[0].name}</div>
              <div className="truncate text-xs text-zinc-500">{users[0].customStatus}</div>
            </div>
          </div>
          <nav className="space-y-1">
            {nav.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-zinc-400 transition hover:bg-white/[0.08] hover:text-white",
                    active && "bg-white/10 text-white"
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <div className="mt-6 rounded-xl border border-cyan-300/20 bg-cyan-300/[0.08] p-4">
            <div className="text-sm font-semibold text-cyan-100">Status</div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
              {["Online", "Away", "Busy", "Invisible"].map((status) => (
                <button key={status} className="rounded-lg bg-white/[0.08] px-2 py-2 text-zinc-300 transition hover:bg-white/[0.14]">
                  {status}
                </button>
              ))}
            </div>
          </div>
        </aside>

        <main className="flex min-w-0 flex-1 flex-col pb-20 lg:pb-0">
          <header className="sticky top-0 z-40 border-b border-white/[0.08] bg-[#08090d]/[0.72] px-4 py-3 backdrop-blur-xl sm:px-6">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white text-zinc-950 lg:hidden">
                <Sparkles className="h-5 w-5" />
              </Link>
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                <Input className="pl-9" placeholder="Search communities, friends, notes, channels" />
              </div>
              <Button size="icon" variant="secondary" aria-label="Notifications">
                <Bell className="h-4 w-4" />
              </Button>
            </div>
          </header>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.38, ease: "easeOut" }}
            className="min-h-0 flex-1 px-4 py-5 sm:px-6"
          >
            {children}
          </motion.div>
        </main>

        <aside className="hidden w-[292px] shrink-0 border-l border-white/[0.08] bg-black/[0.18] px-4 py-5 backdrop-blur-xl 2xl:block">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold">Online friends</div>
              <div className="text-xs text-zinc-500">12 active right now</div>
            </div>
            <Badge>Live</Badge>
          </div>
          <div className="space-y-3">
            {users.map((user) => (
              <Link href={`/profile/${user.id}`} key={user.id} className="flex items-center gap-3 rounded-lg p-2 transition hover:bg-white/[0.08]">
                <Avatar src={user.avatar} alt={user.name} status={user.status} size="sm" />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-sm font-medium">{user.name}</div>
                  <div className="truncate text-xs text-zinc-500">{user.customStatus}</div>
                </div>
              </Link>
            ))}
          </div>
        </aside>
      </div>

      <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-white/10 bg-[#08090d]/[0.88] px-2 py-2 backdrop-blur-xl lg:hidden">
        <div className="mx-auto grid max-w-md grid-cols-6 gap-1">
          {nav.map((item) => {
            const Icon = item.icon;
            const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
            return (
              <Link
                href={item.href}
                key={item.href}
                className={cn("flex h-11 items-center justify-center rounded-lg text-zinc-500", active && "bg-white/10 text-white")}
                aria-label={item.label}
              >
                <Icon className="h-5 w-5" />
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
