import { Bell, Eye, LockKeyhole, Monitor, Palette, UserRound } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const groups = [
  { title: "Account settings", icon: UserRound, fields: ["Display name", "Email address", "Username"] },
  { title: "Privacy settings", icon: LockKeyhole, fields: ["DM permissions", "Profile visibility", "Note visibility"] },
  { title: "Notification settings", icon: Bell, fields: ["Mentions", "Friend requests", "Community updates"] },
  { title: "Appearance settings", icon: Palette, fields: ["Theme", "Accent color", "Message density"] }
];

export default function SettingsPage() {
  return (
    <AppShell>
      <div className="mb-5">
        <h1 className="text-2xl font-semibold">Settings</h1>
        <p className="mt-2 text-sm text-zinc-500">Tune account, privacy, notifications, and appearance preferences.</p>
      </div>
      <div className="grid gap-4 xl:grid-cols-[280px_1fr]">
        <Card className="p-3">
          {groups.map((group) => {
            const Icon = group.icon;
            return (
              <button key={group.title} className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-zinc-400 hover:bg-white/[0.08] hover:text-white">
                <Icon className="h-4 w-4" /> {group.title}
              </button>
            );
          })}
          <button className="mt-4 flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-zinc-400 hover:bg-white/[0.08] hover:text-white">
            <Eye className="h-4 w-4" /> Invisible mode
          </button>
          <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-zinc-400 hover:bg-white/[0.08] hover:text-white">
            <Monitor className="h-4 w-4" /> Devices
          </button>
        </Card>
        <div className="space-y-4">
          {groups.map((group) => {
            const Icon = group.icon;
            return (
              <Card key={group.title} className="p-4">
                <div className="mb-4 flex items-center justify-between">
                  <div className="flex items-center gap-2 font-semibold">
                    <Icon className="h-4 w-4 text-cyan-200" /> {group.title}
                  </div>
                  <Badge>Saved</Badge>
                </div>
                <div className="grid gap-3 md:grid-cols-3">
                  {group.fields.map((field) => (
                    <label key={field} className="block">
                      <span className="mb-2 block text-xs text-zinc-500">{field}</span>
                      <Input placeholder={field} />
                    </label>
                  ))}
                </div>
              </Card>
            );
          })}
          <div className="flex justify-end gap-3">
            <Button variant="secondary">Cancel</Button>
            <Button>Save changes</Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
