import type { Config } from "tailwindcss";
import animate from "tailwindcss-animate";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}"
  ],
  safelist: [
    "from-cyan-400",
    "to-fuchsia-400",
    "from-violet-400",
    "to-blue-400",
    "from-emerald-300",
    "to-sky-400"
  ],
  theme: {
    extend: {
      colors: {
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))"
        },
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))"
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))"
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))"
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))"
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))"
        }
      },
      borderRadius: {
        xl: "1rem",
        lg: "0.75rem",
        md: "0.5rem",
        sm: "0.375rem"
      },
      boxShadow: {
        glow: "0 0 40px rgba(96, 165, 250, 0.22)",
        panel: "0 24px 70px rgba(0, 0, 0, 0.38)"
      },
      backgroundImage: {
        "mesh-dark":
          "radial-gradient(circle at top left, rgba(20, 184, 166, 0.14), transparent 34%), radial-gradient(circle at top right, rgba(244, 114, 182, 0.12), transparent 28%), linear-gradient(135deg, #08090d 0%, #11131b 46%, #08090d 100%)"
      }
    }
  },
  plugins: [animate]
};

export default config;
