import { AuthPanel } from "@/components/app/auth-panel";

export default function SignupPage() {
  return <AuthPanel mode="signup" />;
}
