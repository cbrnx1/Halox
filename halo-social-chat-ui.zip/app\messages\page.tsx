import { AppShell } from "@/components/app/app-shell";
import { ChatPanel } from "@/components/app/chat-panel";

export default function MessagesPage() {
  return (
    <AppShell>
      <ChatPanel />
    </AppShell>
  );
}
