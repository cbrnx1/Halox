import { Avatar } from "@/components/ui/avatar";
import { User } from "@/lib/types";

export function NoteBubble({ user }: { user: User }) {
  return (
    <div className="flex w-20 shrink-0 flex-col items-center gap-2">
      <div className="relative">
        {user.note ? (
          <div className="absolute -top-7 left-1/2 z-10 w-max max-w-[112px] -translate-x-1/2 rounded-full border border-white/[0.12] bg-zinc-950/90 px-3 py-1 text-center text-[11px] text-white shadow-panel backdrop-blur-xl">
            {user.note}
          </div>
        ) : null}
        <Avatar src={user.avatar} alt={user.name} status={user.status} size="lg" />
      </div>
      <div className="w-full truncate text-center text-xs text-zinc-400">{user.name.split(" ")[0]}</div>
    </div>
  );
}
