import { notFound } from "next/navigation";
import { AppShell } from "@/components/app/app-shell";
import { CommunityProfile } from "@/components/app/community-view";
import { communities } from "@/lib/mock-data";

export default async function CommunityPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const community = communities.find((item) => item.id === id);

  if (!community) {
    notFound();
  }

  return (
    <AppShell>
      <CommunityProfile community={community} />
    </AppShell>
  );
}
