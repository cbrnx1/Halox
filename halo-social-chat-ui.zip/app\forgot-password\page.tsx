import { AuthPanel } from "@/components/app/auth-panel";

export default function ForgotPasswordPage() {
  return <AuthPanel mode="forgot" />;
}
