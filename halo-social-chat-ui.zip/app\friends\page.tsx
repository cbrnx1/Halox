import { UserCheck, UserPlus, UserX } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { users } from "@/lib/mock-data";

const sections = [
  { title: "Friends", icon: UserCheck, action: "Message" },
  { title: "Pending requests", icon: UserPlus, action: "Accept" },
  { title: "Suggested users", icon: UserPlus, action: "Add" },
  { title: "Blocked users", icon: UserX, action: "Unblock" }
];

export default function FriendsPage() {
  return (
    <AppShell>
      <div className="mb-5">
        <h1 className="text-2xl font-semibold">Friends</h1>
        <p className="mt-2 text-sm text-zinc-500">Manage your friend graph, requests, suggestions, and blocked accounts.</p>
      </div>
      <div className="grid gap-4 xl:grid-cols-2">
        {sections.map((section, index) => {
          const Icon = section.icon;
          return (
            <Card key={section.title} className="p-4">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2 font-semibold">
                  <Icon className="h-4 w-4 text-cyan-200" /> {section.title}
                </div>
                <Badge>{index === 0 ? users.length : index + 1}</Badge>
              </div>
              <div className="space-y-3">
                {users.slice(0, index === 3 ? 2 : 4).map((user) => (
                  <div key={`${section.title}-${user.id}`} className="flex items-center gap-3 rounded-lg border border-white/[0.08] bg-white/5 p-3">
                    <Avatar src={user.avatar} alt={user.name} status={user.status} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{user.name}</div>
                      <div className="truncate text-xs text-zinc-500">{user.handle}</div>
                    </div>
                    <Button variant={index === 3 ? "danger" : "secondary"} size="sm">{section.action}</Button>
                  </div>
                ))}
              </div>
            </Card>
          );
        })}
      </div>
    </AppShell>
  );
}
