"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, LockKeyhole, Mail, Sparkles, UserRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

type AuthPanelProps = {
  mode: "login" | "signup" | "forgot";
};

export function AuthPanel({ mode }: AuthPanelProps) {
  const isSignup = mode === "signup";
  const isForgot = mode === "forgot";

  return (
    <main className="flex min-h-screen items-center justify-center bg-mesh-dark px-4 py-10 text-white">
      <motion.div
        initial={{ opacity: 0, scale: 0.96, y: 18 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.42, ease: "easeOut" }}
        className="grid w-full max-w-5xl gap-5 lg:grid-cols-[1.05fr_0.95fr]"
      >
        <section
          className="flex min-h-[520px] flex-col justify-between overflow-hidden rounded-xl border border-white/10 bg-cover bg-center p-6 shadow-panel"
          style={{
            backgroundImage:
              "url(https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80)"
          }}
        >
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-white text-zinc-950">
            <Sparkles className="h-5 w-5" />
          </div>
          <div className="max-w-md">
            <div className="mb-3 inline-flex rounded-full border border-white/[0.12] bg-black/[0.35] px-3 py-1 text-xs text-cyan-100 backdrop-blur-xl">
              Communities, notes, and private chat in one calm space
            </div>
            <h1 className="text-4xl font-semibold tracking-normal sm:text-5xl">Halo</h1>
            <p className="mt-3 text-sm leading-6 text-zinc-200">
              A premium social chat experience for close friends, creative groups, and communities that feel alive.
            </p>
          </div>
        </section>

        <Card className="p-5 sm:p-7">
          <div className="mb-8">
            <div className="mb-2 text-sm text-cyan-200">
              {isForgot ? "Reset access" : isSignup ? "Create your account" : "Welcome back"}
            </div>
            <h2 className="text-2xl font-semibold">
              {isForgot ? "Forgot password" : isSignup ? "Join Halo" : "Log in"}
            </h2>
            <p className="mt-2 text-sm leading-6 text-zinc-400">
              {isForgot
                ? "Enter your email and we will send a recovery link."
                : "Continue into your communities, notes, friends, and direct messages."}
            </p>
          </div>

          <form className="space-y-4">
            {isSignup ? (
              <label className="block">
                <span className="mb-2 flex items-center gap-2 text-xs font-medium text-zinc-400">
                  <UserRound className="h-3.5 w-3.5" /> Display name
                </span>
                <Input placeholder="Mira Chen" />
              </label>
            ) : null}
            <label className="block">
              <span className="mb-2 flex items-center gap-2 text-xs font-medium text-zinc-400">
                <Mail className="h-3.5 w-3.5" /> Email
              </span>
              <Input type="email" placeholder="you@example.com" />
            </label>
            {!isForgot ? (
              <label className="block">
                <span className="mb-2 flex items-center gap-2 text-xs font-medium text-zinc-400">
                  <LockKeyhole className="h-3.5 w-3.5" /> Password
                </span>
                <Input type="password" placeholder="••••••••" />
              </label>
            ) : null}
            <Button type="button" className="w-full">
              {isForgot ? "Send reset link" : isSignup ? "Create account" : "Continue"} <ArrowRight className="h-4 w-4" />
            </Button>
          </form>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 text-sm text-zinc-400">
            {isForgot ? (
              <Link href="/login" className="text-cyan-200 hover:text-white">
                Back to login
              </Link>
            ) : (
              <Link href="/forgot-password" className="text-cyan-200 hover:text-white">
                Forgot password?
              </Link>
            )}
            {!isForgot ? (
              <Link href={isSignup ? "/login" : "/signup"} className="text-cyan-200 hover:text-white">
                {isSignup ? "Already have an account?" : "Create account"}
              </Link>
            ) : null}
          </div>
        </Card>
      </motion.div>
    </main>
  );
}
