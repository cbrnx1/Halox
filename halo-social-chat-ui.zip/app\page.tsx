import Link from "next/link";
import { Bell, ChevronRight, Hash, MessageCircle, Radio, UserPlus } from "lucide-react";
import { AppShell } from "@/components/app/app-shell";
import { NoteBubble } from "@/components/app/note-bubble";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { communities, notifications, users } from "@/lib/mock-data";
import { cn } from "@/lib/utils";

export default function HomePage() {
  return (
    <AppShell>
      <div className="space-y-5">
        <section className="flex gap-4 overflow-x-auto px-1 pb-3 pt-8 no-scrollbar">
          {users.map((user) => (
            <NoteBubble key={user.id} user={user} />
          ))}
        </section>

        <section className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            <Card className="overflow-hidden">
              <div
                className="relative min-h-[280px] bg-cover bg-center p-5 sm:p-7"
                style={{
                  backgroundImage:
                    "url(https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=1400&q=80)"
                }}
              >
                <div className="absolute inset-0 bg-gradient-to-r from-black/75 via-black/[0.45] to-transparent" />
                <div className="relative flex max-w-xl flex-col justify-end pt-24">
                  <Badge className="mb-4 w-max text-cyan-100">Live now in Design Lab</Badge>
                  <h1 className="text-3xl font-semibold tracking-normal sm:text-5xl">Your communities are awake.</h1>
                  <p className="mt-3 text-sm leading-6 text-zinc-300">
                    Catch up on friend notes, jump into active channels, or send a private message from one calm dashboard.
                  </p>
                  <div className="mt-5 flex flex-wrap gap-3">
                    <Link href="/messages"><Button><MessageCircle className="h-4 w-4" /> Open DMs</Button></Link>
                    <Link href="/communities"><Button variant="secondary"><Hash className="h-4 w-4" /> Browse communities</Button></Link>
                  </div>
                </div>
              </div>
            </Card>

            <div className="grid gap-4 md:grid-cols-3">
              {communities.map((community) => (
                <Link href={`/communities/${community.id}`} key={community.id}>
                  <Card className="p-4 transition hover:-translate-y-1 hover:bg-white/10">
                    <div className={cn("mb-4 h-12 w-12 rounded-xl bg-gradient-to-br p-[1px]", community.accent)}>
                      <div className="flex h-full w-full items-center justify-center rounded-xl bg-zinc-950 text-sm font-black">{community.icon}</div>
                    </div>
                    <div className="font-semibold">{community.name}</div>
                    <div className="mt-1 text-sm text-zinc-500">{community.online.toLocaleString()} online</div>
                  </Card>
                </Link>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            <Card className="p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="font-semibold">Today</div>
                <Badge>24h notes</Badge>
              </div>
              <div className="space-y-3">
                {notifications.slice(0, 3).map((item) => (
                  <div key={item.title} className="flex gap-3 rounded-lg border border-white/[0.08] bg-white/5 p-3">
                    <div className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/[0.08]">
                      {item.type === "Friend" ? <UserPlus className="h-4 w-4" /> : item.type === "Voice" ? <Radio className="h-4 w-4" /> : <Bell className="h-4 w-4" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-medium">{item.title}</div>
                      <div className="truncate text-xs text-zinc-500">{item.detail}</div>
                    </div>
                    <span className="text-xs text-zinc-500">{item.time}</span>
                  </div>
                ))}
              </div>
            </Card>

            <Card className="p-4">
              <div className="mb-3 flex items-center justify-between">
                <div className="font-semibold">Suggested friends</div>
                <ChevronRight className="h-4 w-4 text-zinc-500" />
              </div>
              <div className="space-y-3">
                {users.slice(1).map((user) => (
                  <div key={user.id} className="flex items-center gap-3">
                    <Avatar src={user.avatar} alt={user.name} status={user.status} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{user.name}</div>
                      <div className="truncate text-xs text-zinc-500">{user.handle}</div>
                    </div>
                    <Button variant="secondary" size="sm">Add</Button>
                  </div>
                ))}
              </div>
            </Card>
          </div>
        </section>
      </div>
    </AppShell>
  );
}
