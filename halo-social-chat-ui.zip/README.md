# Halo Social Chat UI

A frontend-only Next.js 15 prototype for a premium social chat platform that blends Discord-style communities with Instagram-style notes.

## Stack

- Next.js 15 App Router
- TypeScript
- Tailwind CSS
- shadcn/ui-inspired reusable components
- Lucide Icons
- Framer Motion

## Routes

- `/` Home dashboard
- `/login`
- `/signup`
- `/forgot-password`
- `/messages`
- `/communities`
- `/communities/design-lab`
- `/profile/mira`
- `/friends`
- `/notifications`
- `/settings`

## Run

Install dependencies and start the frontend:

```bash
npm install
npm run dev
```
