import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Halo Social Chat",
  description: "A premium frontend for communities, notes, friends, and real-time messaging."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-mesh-dark antialiased">{children}</body>
    </html>
  );
}
